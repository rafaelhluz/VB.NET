﻿Public Class FrmPrincipal02

    Dim ContaDaGabriela As New ContaCorrente

    Public Sub New()

        ' Esta chamada é requerida pelo designer.
        InitializeComponent()

        ' Adicione qualquer inicialização após a chamada InitializeComponent().

        ' Inicializar os dados da classe
        ContaDaGabriela.titular = "Gabriela"
        ContaDaGabriela.agencia = "123"
        ContaDaGabriela.conta = 123456

        TxtSaldoAtual.Text = ContaDaGabriela.saldo.ToString

        LblBemVindo.Text = "Bem-vindo " + ContaDaGabriela.titular + " Agência: " _
            + ContaDaGabriela.agencia.ToString + " Conta corrente: " + ContaDaGabriela.conta.ToString


    End Sub

    Private Sub BtmSacar_Click(sender As Object, e As EventArgs) Handles BtmSacar.Click

        TxtResultadoSaque.Text = ""
        TxtSaldo.Text = ""

        Dim valorSacar As Double = Val(TxtValorSacar.Text)
        Dim retornoSaque As Boolean = ContaDaGabriela.Sacar(valorSacar)

        If retornoSaque = False Then
            TxtResultadoSaque.Text = "Saque não efetuado."
        Else
            TxtSaldo.Text = ContaDaGabriela.saldo.ToString
            TxtResultadoSaque.Text = "Saque efetuado com sucesso."
        End If

    End Sub
End Class