﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPrincipal02
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        LblPrincipal02 = New Label()
        LblValorSacar = New Label()
        TxtValorSacar = New TextBox()
        BtmSacar = New Button()
        TxtSaldo = New TextBox()
        LblSaldo = New Label()
        LblResultadoSaque = New Label()
        TxtResultadoSaque = New TextBox()
        TxtSaldoAtual = New TextBox()
        LblSaldoAtual = New Label()
        LblBemVindo = New Label()
        SuspendLayout()
        ' 
        ' LblPrincipal02
        ' 
        LblPrincipal02.AutoSize = True
        LblPrincipal02.Location = New Point(12, 9)
        LblPrincipal02.Name = "LblPrincipal02"
        LblPrincipal02.Size = New Size(184, 15)
        LblPrincipal02.TabIndex = 0
        LblPrincipal02.Text = "1 - primeira classe - formulário 02"
        ' 
        ' LblValorSacar
        ' 
        LblValorSacar.AutoSize = True
        LblValorSacar.Location = New Point(12, 135)
        LblValorSacar.Name = "LblValorSacar"
        LblValorSacar.Size = New Size(100, 15)
        LblValorSacar.TabIndex = 1
        LblValorSacar.Text = "Valor a ser sacado"
        ' 
        ' TxtValorSacar
        ' 
        TxtValorSacar.Location = New Point(12, 153)
        TxtValorSacar.Name = "TxtValorSacar"
        TxtValorSacar.Size = New Size(184, 23)
        TxtValorSacar.TabIndex = 2
        ' 
        ' BtmSacar
        ' 
        BtmSacar.Location = New Point(12, 182)
        BtmSacar.Name = "BtmSacar"
        BtmSacar.Size = New Size(184, 23)
        BtmSacar.TabIndex = 3
        BtmSacar.Text = "Efetuar saque"
        BtmSacar.UseVisualStyleBackColor = True
        ' 
        ' TxtSaldo
        ' 
        TxtSaldo.Location = New Point(12, 233)
        TxtSaldo.Name = "TxtSaldo"
        TxtSaldo.Size = New Size(184, 23)
        TxtSaldo.TabIndex = 5
        ' 
        ' LblSaldo
        ' 
        LblSaldo.AutoSize = True
        LblSaldo.Location = New Point(12, 215)
        LblSaldo.Name = "LblSaldo"
        LblSaldo.Size = New Size(67, 15)
        LblSaldo.TabIndex = 4
        LblSaldo.Text = "Novo saldo"
        ' 
        ' LblResultadoSaque
        ' 
        LblResultadoSaque.AutoSize = True
        LblResultadoSaque.Location = New Point(12, 259)
        LblResultadoSaque.Name = "LblResultadoSaque"
        LblResultadoSaque.Size = New Size(110, 15)
        LblResultadoSaque.TabIndex = 6
        LblResultadoSaque.Text = "Resultado do saque"
        ' 
        ' TxtResultadoSaque
        ' 
        TxtResultadoSaque.Location = New Point(12, 277)
        TxtResultadoSaque.Name = "TxtResultadoSaque"
        TxtResultadoSaque.Size = New Size(184, 23)
        TxtResultadoSaque.TabIndex = 7
        ' 
        ' TxtSaldoAtual
        ' 
        TxtSaldoAtual.Location = New Point(12, 109)
        TxtSaldoAtual.Name = "TxtSaldoAtual"
        TxtSaldoAtual.Size = New Size(184, 23)
        TxtSaldoAtual.TabIndex = 9
        ' 
        ' LblSaldoAtual
        ' 
        LblSaldoAtual.AutoSize = True
        LblSaldoAtual.Location = New Point(12, 91)
        LblSaldoAtual.Name = "LblSaldoAtual"
        LblSaldoAtual.Size = New Size(65, 15)
        LblSaldoAtual.TabIndex = 8
        LblSaldoAtual.Text = "Saldo atual"
        ' 
        ' LblBemVindo
        ' 
        LblBemVindo.AutoSize = True
        LblBemVindo.Location = New Point(12, 51)
        LblBemVindo.Name = "LblBemVindo"
        LblBemVindo.Size = New Size(64, 15)
        LblBemVindo.TabIndex = 10
        LblBemVindo.Text = "Bem vindo"
        ' 
        ' FrmPrincipal02
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(581, 377)
        Controls.Add(LblBemVindo)
        Controls.Add(TxtSaldoAtual)
        Controls.Add(LblSaldoAtual)
        Controls.Add(TxtResultadoSaque)
        Controls.Add(LblResultadoSaque)
        Controls.Add(TxtSaldo)
        Controls.Add(LblSaldo)
        Controls.Add(BtmSacar)
        Controls.Add(TxtValorSacar)
        Controls.Add(LblValorSacar)
        Controls.Add(LblPrincipal02)
        Name = "FrmPrincipal02"
        StartPosition = FormStartPosition.CenterScreen
        Text = "1 - primeira classe - formulário 02"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents LblPrincipal02 As Label
    Friend WithEvents LblValorSacar As Label
    Friend WithEvents TxtValorSacar As TextBox
    Friend WithEvents BtmSacar As Button
    Friend WithEvents TxtSaldo As TextBox
    Friend WithEvents LblSaldo As Label
    Friend WithEvents LblResultadoSaque As Label
    Friend WithEvents TxtResultadoSaque As TextBox
    Friend WithEvents TxtSaldoAtual As TextBox
    Friend WithEvents LblSaldoAtual As Label
    Friend WithEvents LblBemVindo As Label
End Class
