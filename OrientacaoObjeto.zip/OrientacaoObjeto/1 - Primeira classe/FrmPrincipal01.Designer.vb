﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmPrincipal01
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        LblPrincipal = New Label()
        BtmAcao = New Button()
        LblSaldo = New Label()
        LblIncremento = New Label()
        TxtSaldo = New TextBox()
        TxtIncremento = New TextBox()
        BtmAcao2 = New Button()
        BtmValRef = New Button()
        SuspendLayout()
        ' 
        ' LblPrincipal
        ' 
        LblPrincipal.AutoSize = True
        LblPrincipal.Location = New Point(12, 9)
        LblPrincipal.Name = "LblPrincipal"
        LblPrincipal.Size = New Size(102, 15)
        LblPrincipal.TabIndex = 0
        LblPrincipal.Text = "1 - Primeira classe"
        ' 
        ' BtmAcao
        ' 
        BtmAcao.Location = New Point(12, 37)
        BtmAcao.Name = "BtmAcao"
        BtmAcao.Size = New Size(96, 23)
        BtmAcao.TabIndex = 1
        BtmAcao.Text = "Conta Gabriela"
        BtmAcao.UseVisualStyleBackColor = True
        ' 
        ' LblSaldo
        ' 
        LblSaldo.AutoSize = True
        LblSaldo.Location = New Point(12, 86)
        LblSaldo.Name = "LblSaldo"
        LblSaldo.Size = New Size(36, 15)
        LblSaldo.TabIndex = 2
        LblSaldo.Text = "Saldo"
        ' 
        ' LblIncremento
        ' 
        LblIncremento.AutoSize = True
        LblIncremento.Location = New Point(155, 86)
        LblIncremento.Name = "LblIncremento"
        LblIncremento.Size = New Size(68, 15)
        LblIncremento.TabIndex = 3
        LblIncremento.Text = "Incremento"
        ' 
        ' TxtSaldo
        ' 
        TxtSaldo.Location = New Point(12, 104)
        TxtSaldo.Name = "TxtSaldo"
        TxtSaldo.Size = New Size(100, 23)
        TxtSaldo.TabIndex = 4
        ' 
        ' TxtIncremento
        ' 
        TxtIncremento.Location = New Point(155, 104)
        TxtIncremento.Name = "TxtIncremento"
        TxtIncremento.Size = New Size(100, 23)
        TxtIncremento.TabIndex = 5
        ' 
        ' BtmAcao2
        ' 
        BtmAcao2.Location = New Point(155, 37)
        BtmAcao2.Name = "BtmAcao2"
        BtmAcao2.Size = New Size(100, 23)
        BtmAcao2.TabIndex = 6
        BtmAcao2.Text = "Conta Bruno"
        BtmAcao2.UseVisualStyleBackColor = True
        ' 
        ' BtmValRef
        ' 
        BtmValRef.Location = New Point(307, 37)
        BtmValRef.Name = "BtmValRef"
        BtmValRef.Size = New Size(100, 23)
        BtmValRef.TabIndex = 7
        BtmValRef.Text = "Clique aqui"
        BtmValRef.UseVisualStyleBackColor = True
        ' 
        ' FrmPrincipal01
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(BtmValRef)
        Controls.Add(BtmAcao2)
        Controls.Add(TxtIncremento)
        Controls.Add(TxtSaldo)
        Controls.Add(LblIncremento)
        Controls.Add(LblSaldo)
        Controls.Add(BtmAcao)
        Controls.Add(LblPrincipal)
        Name = "FrmPrincipal01"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents LblPrincipal As Label
    Friend WithEvents BtmAcao As Button
    Friend WithEvents LblSaldo As Label
    Friend WithEvents LblIncremento As Label
    Friend WithEvents TxtSaldo As TextBox
    Friend WithEvents TxtIncremento As TextBox
    Friend WithEvents BtmAcao2 As Button
    Friend WithEvents BtmValRef As Button

End Class
