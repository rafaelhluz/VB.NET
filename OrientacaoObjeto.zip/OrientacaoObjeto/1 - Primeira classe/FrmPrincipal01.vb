﻿Public Class FrmPrincipal01
    Public Sub New()

        ' Esta chamada é requerida pelo designer.
        InitializeComponent()

        ' Adicione qualquer inicialização após a chamada InitializeComponent().




    End Sub
    Private Sub BtmAcao_Click(sender As Object, e As EventArgs) Handles BtmAcao.Click

        Dim ContaCorrente1 As New ContaCorrente
        ContaCorrente1.titular = "Gabriela"
        ContaCorrente1.agencia = "123"
        ContaCorrente1.conta = 123456
        ContaCorrente1.saldo = Val(TxtSaldo.Text)

        MsgBox("O saldo da " + ContaCorrente1.titular + " na C/C " + ContaCorrente1.agencia.ToString _
               + " - " + ContaCorrente1.conta.ToString + " é " + ContaCorrente1.saldo.ToString)

        Dim vIncremento As Double = Val(TxtIncremento.Text)
        ContaCorrente1.saldo += vIncremento

        MsgBox("O saldo da " + ContaCorrente1.titular + " na C/C " + ContaCorrente1.agencia.ToString _
               + " - " + ContaCorrente1.conta.ToString + " é " + ContaCorrente1.saldo.ToString)



    End Sub

    Private Sub BtmAcao2_Click(sender As Object, e As EventArgs) Handles BtmAcao2.Click

        Dim ContaCorrente2 As New ContaCorrente

    End Sub

    Private Sub BtmValRef_Click(sender As Object, e As EventArgs) Handles BtmValRef.Click




    End Sub
End Class
