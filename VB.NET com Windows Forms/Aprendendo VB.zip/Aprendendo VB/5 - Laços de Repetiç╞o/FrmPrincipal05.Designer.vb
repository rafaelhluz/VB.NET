﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmPrincipal05
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        BtmWhile = New Button()
        Lbl_NomeProjeto = New Label()
        LblPrincipal = New Label()
        LblRendimento = New Label()
        TxtPrincipal = New TextBox()
        TxtRendimento = New TextBox()
        LblPeriodos = New Label()
        TxtPeriodos = New TextBox()
        TxtExtrato = New TextBox()
        Label1 = New Label()
        BtmFor = New Button()
        GrpGrupo1 = New GroupBox()
        GrpGrupo2 = New GroupBox()
        Label2 = New Label()
        TxtResultado = New TextBox()
        BtmCalcula = New Button()
        TxtAcrescimoRendimento = New TextBox()
        TxtAnos = New TextBox()
        TxtRendimento2 = New TextBox()
        TxtPrincipal2 = New TextBox()
        LblAcrescimoRendimento = New Label()
        LblAnos = New Label()
        LblRendimento2 = New Label()
        LblPrincipal2 = New Label()
        TxtLimite = New TextBox()
        LblLimite = New Label()
        GrpGrupo1.SuspendLayout()
        GrpGrupo2.SuspendLayout()
        SuspendLayout()
        ' 
        ' BtmWhile
        ' 
        BtmWhile.Location = New Point(9, 70)
        BtmWhile.Name = "BtmWhile"
        BtmWhile.Size = New Size(264, 27)
        BtmWhile.TabIndex = 0
        BtmWhile.Text = "Calcular usando while"
        BtmWhile.UseVisualStyleBackColor = True
        BtmWhile.UseWaitCursor = True
        ' 
        ' Lbl_NomeProjeto
        ' 
        Lbl_NomeProjeto.AutoSize = True
        Lbl_NomeProjeto.Location = New Point(12, 9)
        Lbl_NomeProjeto.Name = "Lbl_NomeProjeto"
        Lbl_NomeProjeto.Size = New Size(122, 15)
        Lbl_NomeProjeto.TabIndex = 1
        Lbl_NomeProjeto.Text = "5 - Laços de repetição"
        Lbl_NomeProjeto.UseWaitCursor = True
        ' 
        ' LblPrincipal
        ' 
        LblPrincipal.AutoSize = True
        LblPrincipal.Location = New Point(9, 23)
        LblPrincipal.Name = "LblPrincipal"
        LblPrincipal.Size = New Size(84, 15)
        LblPrincipal.TabIndex = 2
        LblPrincipal.Text = "Valor investido"
        LblPrincipal.UseWaitCursor = True
        ' 
        ' LblRendimento
        ' 
        LblRendimento.AutoSize = True
        LblRendimento.Location = New Point(189, 23)
        LblRendimento.Name = "LblRendimento"
        LblRendimento.Size = New Size(55, 15)
        LblRendimento.TabIndex = 3
        LblRendimento.Text = "Juros (%)"
        LblRendimento.UseWaitCursor = True
        ' 
        ' TxtPrincipal
        ' 
        TxtPrincipal.Location = New Point(9, 41)
        TxtPrincipal.Name = "TxtPrincipal"
        TxtPrincipal.Size = New Size(84, 23)
        TxtPrincipal.TabIndex = 4
        TxtPrincipal.UseWaitCursor = True
        ' 
        ' TxtRendimento
        ' 
        TxtRendimento.Location = New Point(189, 41)
        TxtRendimento.Name = "TxtRendimento"
        TxtRendimento.Size = New Size(84, 23)
        TxtRendimento.TabIndex = 5
        TxtRendimento.UseWaitCursor = True
        ' 
        ' LblPeriodos
        ' 
        LblPeriodos.AutoSize = True
        LblPeriodos.Location = New Point(99, 23)
        LblPeriodos.Name = "LblPeriodos"
        LblPeriodos.Size = New Size(53, 15)
        LblPeriodos.TabIndex = 6
        LblPeriodos.Text = "Períodos"
        LblPeriodos.UseWaitCursor = True
        ' 
        ' TxtPeriodos
        ' 
        TxtPeriodos.Location = New Point(99, 41)
        TxtPeriodos.Name = "TxtPeriodos"
        TxtPeriodos.Size = New Size(84, 23)
        TxtPeriodos.TabIndex = 7
        TxtPeriodos.UseWaitCursor = True
        ' 
        ' TxtExtrato
        ' 
        TxtExtrato.Location = New Point(279, 41)
        TxtExtrato.Multiline = True
        TxtExtrato.Name = "TxtExtrato"
        TxtExtrato.ScrollBars = ScrollBars.Vertical
        TxtExtrato.Size = New Size(438, 89)
        TxtExtrato.TabIndex = 8
        TxtExtrato.UseWaitCursor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(279, 23)
        Label1.Name = "Label1"
        Label1.Size = New Size(44, 15)
        Label1.TabIndex = 9
        Label1.Text = "Extrato"
        Label1.UseWaitCursor = True
        ' 
        ' BtmFor
        ' 
        BtmFor.Location = New Point(9, 103)
        BtmFor.Name = "BtmFor"
        BtmFor.Size = New Size(264, 27)
        BtmFor.TabIndex = 10
        BtmFor.Text = "Calcular usando for"
        BtmFor.UseVisualStyleBackColor = True
        BtmFor.UseWaitCursor = True
        ' 
        ' GrpGrupo1
        ' 
        GrpGrupo1.Controls.Add(BtmWhile)
        GrpGrupo1.Controls.Add(BtmFor)
        GrpGrupo1.Controls.Add(LblPrincipal)
        GrpGrupo1.Controls.Add(Label1)
        GrpGrupo1.Controls.Add(LblRendimento)
        GrpGrupo1.Controls.Add(TxtExtrato)
        GrpGrupo1.Controls.Add(TxtPrincipal)
        GrpGrupo1.Controls.Add(TxtPeriodos)
        GrpGrupo1.Controls.Add(TxtRendimento)
        GrpGrupo1.Controls.Add(LblPeriodos)
        GrpGrupo1.Location = New Point(12, 40)
        GrpGrupo1.Name = "GrpGrupo1"
        GrpGrupo1.Size = New Size(723, 145)
        GrpGrupo1.TabIndex = 11
        GrpGrupo1.TabStop = False
        GrpGrupo1.Text = "Calculo do investimento por While ou For"
        GrpGrupo1.UseWaitCursor = True
        ' 
        ' GrpGrupo2
        ' 
        GrpGrupo2.Controls.Add(TxtLimite)
        GrpGrupo2.Controls.Add(LblLimite)
        GrpGrupo2.Controls.Add(Label2)
        GrpGrupo2.Controls.Add(TxtResultado)
        GrpGrupo2.Controls.Add(BtmCalcula)
        GrpGrupo2.Controls.Add(TxtAcrescimoRendimento)
        GrpGrupo2.Controls.Add(TxtAnos)
        GrpGrupo2.Controls.Add(TxtRendimento2)
        GrpGrupo2.Controls.Add(TxtPrincipal2)
        GrpGrupo2.Controls.Add(LblAcrescimoRendimento)
        GrpGrupo2.Controls.Add(LblAnos)
        GrpGrupo2.Controls.Add(LblRendimento2)
        GrpGrupo2.Controls.Add(LblPrincipal2)
        GrpGrupo2.Location = New Point(12, 191)
        GrpGrupo2.Name = "GrpGrupo2"
        GrpGrupo2.Size = New Size(717, 203)
        GrpGrupo2.TabIndex = 12
        GrpGrupo2.TabStop = False
        GrpGrupo2.Text = "Cálculo do investimento anual"
        GrpGrupo2.UseWaitCursor = True
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(279, 19)
        Label2.Name = "Label2"
        Label2.Size = New Size(44, 15)
        Label2.TabIndex = 10
        Label2.Text = "Extrato"
        Label2.UseWaitCursor = True
        ' 
        ' TxtResultado
        ' 
        TxtResultado.Location = New Point(279, 37)
        TxtResultado.Multiline = True
        TxtResultado.Name = "TxtResultado"
        TxtResultado.ScrollBars = ScrollBars.Both
        TxtResultado.Size = New Size(438, 160)
        TxtResultado.TabIndex = 9
        TxtResultado.UseWaitCursor = True
        ' 
        ' BtmCalcula
        ' 
        BtmCalcula.Location = New Point(9, 174)
        BtmCalcula.Name = "BtmCalcula"
        BtmCalcula.Size = New Size(174, 23)
        BtmCalcula.TabIndex = 8
        BtmCalcula.Text = "Calcular"
        BtmCalcula.UseVisualStyleBackColor = True
        BtmCalcula.UseWaitCursor = True
        ' 
        ' TxtAcrescimoRendimento
        ' 
        TxtAcrescimoRendimento.Location = New Point(99, 87)
        TxtAcrescimoRendimento.Name = "TxtAcrescimoRendimento"
        TxtAcrescimoRendimento.Size = New Size(84, 23)
        TxtAcrescimoRendimento.TabIndex = 7
        TxtAcrescimoRendimento.UseWaitCursor = True
        ' 
        ' TxtAnos
        ' 
        TxtAnos.Location = New Point(9, 87)
        TxtAnos.Name = "TxtAnos"
        TxtAnos.Size = New Size(84, 23)
        TxtAnos.TabIndex = 6
        TxtAnos.UseWaitCursor = True
        ' 
        ' TxtRendimento2
        ' 
        TxtRendimento2.Location = New Point(99, 37)
        TxtRendimento2.Name = "TxtRendimento2"
        TxtRendimento2.Size = New Size(84, 23)
        TxtRendimento2.TabIndex = 5
        TxtRendimento2.UseWaitCursor = True
        ' 
        ' TxtPrincipal2
        ' 
        TxtPrincipal2.Location = New Point(9, 37)
        TxtPrincipal2.Name = "TxtPrincipal2"
        TxtPrincipal2.Size = New Size(84, 23)
        TxtPrincipal2.TabIndex = 4
        TxtPrincipal2.UseWaitCursor = True
        ' 
        ' LblAcrescimoRendimento
        ' 
        LblAcrescimoRendimento.AutoSize = True
        LblAcrescimoRendimento.Location = New Point(99, 69)
        LblAcrescimoRendimento.Name = "LblAcrescimoRendimento"
        LblAcrescimoRendimento.Size = New Size(113, 15)
        LblAcrescimoRendimento.TabIndex = 3
        LblAcrescimoRendimento.Text = "Acrescimo juros (%)"
        LblAcrescimoRendimento.UseWaitCursor = True
        ' 
        ' LblAnos
        ' 
        LblAnos.AutoSize = True
        LblAnos.Location = New Point(9, 69)
        LblAnos.Name = "LblAnos"
        LblAnos.Size = New Size(87, 15)
        LblAnos.TabIndex = 2
        LblAnos.Text = "Anos aplicados"
        LblAnos.UseWaitCursor = True
        ' 
        ' LblRendimento2
        ' 
        LblRendimento2.AutoSize = True
        LblRendimento2.Location = New Point(99, 19)
        LblRendimento2.Name = "LblRendimento2"
        LblRendimento2.Size = New Size(96, 15)
        LblRendimento2.TabIndex = 1
        LblRendimento2.Text = "Juros mensal (%)"
        LblRendimento2.UseWaitCursor = True
        ' 
        ' LblPrincipal2
        ' 
        LblPrincipal2.AutoSize = True
        LblPrincipal2.Location = New Point(6, 19)
        LblPrincipal2.Name = "LblPrincipal2"
        LblPrincipal2.Size = New Size(84, 15)
        LblPrincipal2.TabIndex = 0
        LblPrincipal2.Text = "Valor investido"
        LblPrincipal2.UseWaitCursor = True
        ' 
        ' TxtLimite
        ' 
        TxtLimite.Location = New Point(9, 136)
        TxtLimite.Name = "TxtLimite"
        TxtLimite.Size = New Size(84, 23)
        TxtLimite.TabIndex = 12
        TxtLimite.UseWaitCursor = True
        ' 
        ' LblLimite
        ' 
        LblLimite.AutoSize = True
        LblLimite.Location = New Point(9, 118)
        LblLimite.Name = "LblLimite"
        LblLimite.Size = New Size(64, 15)
        LblLimite.TabIndex = 11
        LblLimite.Text = "Limite (R$)"
        LblLimite.UseWaitCursor = True
        ' 
        ' FrmPrincipal05
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(747, 406)
        Controls.Add(GrpGrupo2)
        Controls.Add(GrpGrupo1)
        Controls.Add(Lbl_NomeProjeto)
        Cursor = Cursors.IBeam
        Name = "FrmPrincipal05"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Aplicação Alô Mundo"
        UseWaitCursor = True
        GrpGrupo1.ResumeLayout(False)
        GrpGrupo1.PerformLayout()
        GrpGrupo2.ResumeLayout(False)
        GrpGrupo2.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents BtmWhile As Button
    Friend WithEvents Lbl_NomeProjeto As Label
    Friend WithEvents LblPrincipal As Label
    Friend WithEvents LblRendimento As Label
    Friend WithEvents TxtPrincipal As TextBox
    Friend WithEvents TxtRendimento As TextBox
    Friend WithEvents LblPeriodos As Label
    Friend WithEvents TxtPeriodos As TextBox
    Friend WithEvents TxtExtrato As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents BtmFor As Button
    Friend WithEvents GrpGrupo1 As GroupBox
    Friend WithEvents GrpGrupo2 As GroupBox
    Friend WithEvents LblAcrescimoRendimento As Label
    Friend WithEvents LblAnos As Label
    Friend WithEvents LblRendimento2 As Label
    Friend WithEvents LblPrincipal2 As Label
    Friend WithEvents TxtAcrescimoRendimento As TextBox
    Friend WithEvents TxtAnos As TextBox
    Friend WithEvents TxtRendimento2 As TextBox
    Friend WithEvents TxtPrincipal2 As TextBox
    Friend WithEvents BtmCalcula As Button
    Friend WithEvents TxtResultado As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtLimite As TextBox
    Friend WithEvents LblLimite As Label

End Class
