﻿Public Class FrmPrincipal05
    Public Sub New()

        ' Esta chamada é requerida pelo designer.
        InitializeComponent()

        ' Adicione qualquer inicialização após a chamada InitializeComponent().

    End Sub

    Private Sub BtmPrincipal_Click(sender As Object, e As EventArgs) Handles BtmWhile.Click

        Dim investimento = Val(TxtPrincipal.Text)
        Dim rendimento = Val(TxtRendimento.Text)
        Dim periodos As Integer = Val(TxtPeriodos.Text)
        Dim contador = 1
        Dim extrato = ""

        While contador <= periodos
            investimento = investimento + investimento * (rendimento / 100)
            extrato += "O saldo do investimento no mês " + contador.ToString + " é " + investimento.ToString + vbCrLf
            contador += 1
        End While
        TxtExtrato.Text = extrato

    End Sub

    Private Sub BtmFor_Click(sender As Object, e As EventArgs) Handles BtmFor.Click

        Dim investimento = Val(TxtPrincipal.Text)
        Dim rendimento = Val(TxtRendimento.Text)
        Dim periodos As Integer = Val(TxtPeriodos.Text)
        Dim extrato = ""

        For i As Integer = 1 To periodos
            investimento = (investimento + (investimento * (rendimento / 100)))
            extrato += "O saldo do investimento no mês " + i.ToString + " é " + investimento.ToString + vbCrLf
        Next
        TxtExtrato.Text = extrato

    End Sub

    Private Sub BtmCalcula_Click(sender As Object, e As EventArgs) Handles BtmCalcula.Click

        Dim investimento As Double = Val(TxtPrincipal2.Text)
        Dim rendimento As Double = Val(TxtRendimento2.Text)
        Dim anos As Double = Val(TxtAnos.Text)
        Dim acrescimoJuros As Double = Val(TxtAcrescimoRendimento.Text)
        Dim extrato = ""
        Dim contador As Integer = 1
        Dim limite As Double = Val(TxtLimite.Text)
        Dim executouExitFor As Boolean = False

        For i As Integer = 1 To anos
            For j As Integer = 1 To 12
                investimento = (investimento + (investimento * (rendimento / 100)))
                extrato += "O saldo do investimento no ano " + contador.ToString + " é " + investimento.ToString _
                + " usando a taxa  " + rendimento.ToString + "% mês " + vbCrLf

                If (investimento >= limite) Then
                    executouExitFor = True
                    extrato += "O investimento atingiu o valor desejado" + vbCrLf
                    Exit For
                End If
                contador += 1
            Next

            If (executouExitFor) Then
                Exit For
            End If

            rendimento = rendimento + (rendimento * acrescimoJuros / 100)
        Next
        TxtResultado.Text = extrato


    End Sub
End Class
