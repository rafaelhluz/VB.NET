﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmPrincipal03
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Lbl_NomeProjeto = New Label()
        Btm_Char = New Button()
        TxtNumeroChar = New TextBox()
        Lbl_Curso = New Label()
        Txt_Curso = New TextBox()
        Btm_Adicionar = New Button()
        Txt_Lista = New TextBox()
        LblChar = New Label()
        SuspendLayout()
        ' 
        ' Lbl_NomeProjeto
        ' 
        Lbl_NomeProjeto.AutoSize = True
        Lbl_NomeProjeto.Location = New Point(12, 9)
        Lbl_NomeProjeto.Name = "Lbl_NomeProjeto"
        Lbl_NomeProjeto.Size = New Size(110, 15)
        Lbl_NomeProjeto.TabIndex = 1
        Lbl_NomeProjeto.Text = "1 - Primeiro Projeto"
        Lbl_NomeProjeto.UseWaitCursor = True
        ' 
        ' Btm_Char
        ' 
        Btm_Char.Location = New Point(12, 86)
        Btm_Char.Name = "Btm_Char"
        Btm_Char.Size = New Size(258, 24)
        Btm_Char.TabIndex = 2
        Btm_Char.Text = "Button2"
        Btm_Char.UseVisualStyleBackColor = True
        Btm_Char.UseWaitCursor = True
        ' 
        ' TxtNumeroChar
        ' 
        TxtNumeroChar.Location = New Point(12, 57)
        TxtNumeroChar.Name = "TxtNumeroChar"
        TxtNumeroChar.Size = New Size(258, 23)
        TxtNumeroChar.TabIndex = 3
        TxtNumeroChar.UseWaitCursor = True
        ' 
        ' Lbl_Curso
        ' 
        Lbl_Curso.AutoSize = True
        Lbl_Curso.Location = New Point(325, 36)
        Lbl_Curso.Name = "Lbl_Curso"
        Lbl_Curso.Size = New Size(41, 15)
        Lbl_Curso.TabIndex = 4
        Lbl_Curso.Text = "Label1"
        Lbl_Curso.UseWaitCursor = True
        ' 
        ' Txt_Curso
        ' 
        Txt_Curso.Location = New Point(325, 57)
        Txt_Curso.Name = "Txt_Curso"
        Txt_Curso.Size = New Size(258, 23)
        Txt_Curso.TabIndex = 5
        Txt_Curso.UseWaitCursor = True
        ' 
        ' Btm_Adicionar
        ' 
        Btm_Adicionar.Location = New Point(325, 87)
        Btm_Adicionar.Name = "Btm_Adicionar"
        Btm_Adicionar.Size = New Size(258, 23)
        Btm_Adicionar.TabIndex = 6
        Btm_Adicionar.Text = "Button2"
        Btm_Adicionar.UseVisualStyleBackColor = True
        Btm_Adicionar.UseWaitCursor = True
        ' 
        ' Txt_Lista
        ' 
        Txt_Lista.Location = New Point(325, 116)
        Txt_Lista.Multiline = True
        Txt_Lista.Name = "Txt_Lista"
        Txt_Lista.ScrollBars = ScrollBars.Vertical
        Txt_Lista.Size = New Size(258, 213)
        Txt_Lista.TabIndex = 7
        Txt_Lista.UseWaitCursor = True
        ' 
        ' LblChar
        ' 
        LblChar.AutoSize = True
        LblChar.Location = New Point(12, 36)
        LblChar.Name = "LblChar"
        LblChar.Size = New Size(41, 15)
        LblChar.TabIndex = 8
        LblChar.Text = "Label2"
        LblChar.UseWaitCursor = True
        ' 
        ' FrmPrincipal03
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(595, 341)
        Controls.Add(LblChar)
        Controls.Add(Txt_Lista)
        Controls.Add(Btm_Adicionar)
        Controls.Add(Txt_Curso)
        Controls.Add(Lbl_Curso)
        Controls.Add(TxtNumeroChar)
        Controls.Add(Btm_Char)
        Controls.Add(Lbl_NomeProjeto)
        Cursor = Cursors.IBeam
        Name = "FrmPrincipal03"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Aplicação Alô Mundo"
        UseWaitCursor = True
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents Lbl_NomeProjeto As Label
    Friend WithEvents Btm_Char As Button
    Friend WithEvents TxtNumeroChar As TextBox
    Friend WithEvents Lbl_Curso As Label
    Friend WithEvents Txt_Curso As TextBox
    Friend WithEvents Btm_Adicionar As Button
    Friend WithEvents Txt_Lista As TextBox
    Friend WithEvents LblChar As Label

End Class
