﻿Public Class FrmPrincipal03

    Dim listaCurso As String

    Public Sub New()

        ' Esta chamada é requerida pelo designer.
        InitializeComponent()

        ' Adicione qualquer inicialização após a chamada InitializeComponent().

        Lbl_NomeProjeto.Text = "3 - Manipulando textos"
        Me.Text = "3 - Manipulando textos"
        Btm_Char.Text = "Clique para resultado"
        LblChar.Text = "Digite um número para obter o caracter"
        Lbl_Curso.Text = "Digite o seu curso preferido"
        Btm_Adicionar.Text = "Adicione na sua lista"

    End Sub

    Private Sub Btm_Char_Click(sender As Object, e As EventArgs) Handles Btm_Char.Click

        Dim valorChar As Integer = Val(TxtNumeroChar.Text)
        Dim quintaLetra As Char = Chr(valorChar)

        MsgBox("O caracter para o numero " + valorChar.ToString + " é " + quintaLetra)

    End Sub

    Private Sub Btm_Adicionar_Click(sender As Object, e As EventArgs) Handles Btm_Adicionar.Click

        Dim cursoDigitado As String = Txt_Curso.Text
        'vbCrLf serve para quebrar linha
        listaCurso = listaCurso + cursoDigitado + vbCrLf
        Txt_Lista.Text = listaCurso



    End Sub
End Class
