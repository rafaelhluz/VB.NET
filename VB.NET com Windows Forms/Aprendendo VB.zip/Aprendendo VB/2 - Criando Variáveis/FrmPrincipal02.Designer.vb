﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmPrincipal02
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Btm_NumerosInteiros = New Button()
        Lbl_NomeProjeto = New Label()
        Btm_PontoFlutuante = New Button()
        BTm_ConversaoNumeros = New Button()
        Txt_Numerador = New TextBox()
        Txt_Denominador = New TextBox()
        Btm_Resultado = New Button()
        Label1 = New Label()
        Label2 = New Label()
        SuspendLayout()
        ' 
        ' Btm_NumerosInteiros
        ' 
        Btm_NumerosInteiros.Location = New Point(13, 159)
        Btm_NumerosInteiros.Name = "Btm_NumerosInteiros"
        Btm_NumerosInteiros.Size = New Size(236, 42)
        Btm_NumerosInteiros.TabIndex = 0
        Btm_NumerosInteiros.Text = "Exemplos Números inteiros"
        Btm_NumerosInteiros.UseVisualStyleBackColor = True
        Btm_NumerosInteiros.UseWaitCursor = True
        ' 
        ' Lbl_NomeProjeto
        ' 
        Lbl_NomeProjeto.AutoSize = True
        Lbl_NomeProjeto.Location = New Point(12, 9)
        Lbl_NomeProjeto.Name = "Lbl_NomeProjeto"
        Lbl_NomeProjeto.Size = New Size(114, 15)
        Lbl_NomeProjeto.TabIndex = 2
        Lbl_NomeProjeto.Text = "2 - Criando Variáveis"
        Lbl_NomeProjeto.UseWaitCursor = True
        ' 
        ' Btm_PontoFlutuante
        ' 
        Btm_PontoFlutuante.Location = New Point(13, 207)
        Btm_PontoFlutuante.Name = "Btm_PontoFlutuante"
        Btm_PontoFlutuante.Size = New Size(236, 42)
        Btm_PontoFlutuante.TabIndex = 3
        Btm_PontoFlutuante.Text = "Exemplo Números Ponto Flutuante"
        Btm_PontoFlutuante.UseVisualStyleBackColor = True
        Btm_PontoFlutuante.UseWaitCursor = True
        ' 
        ' BTm_ConversaoNumeros
        ' 
        BTm_ConversaoNumeros.Location = New Point(13, 255)
        BTm_ConversaoNumeros.Name = "BTm_ConversaoNumeros"
        BTm_ConversaoNumeros.Size = New Size(236, 42)
        BTm_ConversaoNumeros.TabIndex = 4
        BTm_ConversaoNumeros.Text = "Exemplo de conversão de números"
        BTm_ConversaoNumeros.UseVisualStyleBackColor = True
        BTm_ConversaoNumeros.UseWaitCursor = True
        ' 
        ' Txt_Numerador
        ' 
        Txt_Numerador.Location = New Point(13, 52)
        Txt_Numerador.Name = "Txt_Numerador"
        Txt_Numerador.Size = New Size(236, 23)
        Txt_Numerador.TabIndex = 5
        Txt_Numerador.UseWaitCursor = True
        ' 
        ' Txt_Denominador
        ' 
        Txt_Denominador.Location = New Point(13, 101)
        Txt_Denominador.Name = "Txt_Denominador"
        Txt_Denominador.Size = New Size(236, 23)
        Txt_Denominador.TabIndex = 6
        Txt_Denominador.UseWaitCursor = True
        ' 
        ' Btm_Resultado
        ' 
        Btm_Resultado.Location = New Point(12, 130)
        Btm_Resultado.Name = "Btm_Resultado"
        Btm_Resultado.Size = New Size(237, 23)
        Btm_Resultado.TabIndex = 7
        Btm_Resultado.Text = "Resultado"
        Btm_Resultado.UseVisualStyleBackColor = True
        Btm_Resultado.UseWaitCursor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 34)
        Label1.Name = "Label1"
        Label1.Size = New Size(141, 15)
        Label1.TabIndex = 8
        Label1.Text = "Digite o primeiro número"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(13, 83)
        Label2.Name = "Label2"
        Label2.Size = New Size(142, 15)
        Label2.TabIndex = 9
        Label2.Text = "Digite o segundo número"
        ' 
        ' FrmPrincipal02
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(269, 345)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(Btm_Resultado)
        Controls.Add(Txt_Denominador)
        Controls.Add(Txt_Numerador)
        Controls.Add(BTm_ConversaoNumeros)
        Controls.Add(Btm_PontoFlutuante)
        Controls.Add(Lbl_NomeProjeto)
        Controls.Add(Btm_NumerosInteiros)
        Cursor = Cursors.IBeam
        Name = "FrmPrincipal02"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Aplicação Alô Mundo"
        UseWaitCursor = True
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Btm_NumerosInteiros As Button
    Friend WithEvents Lbl_NomeProjeto As Label
    Friend WithEvents Btm_PontoFlutuante As Button
    Friend WithEvents BTm_ConversaoNumeros As Button
    Friend WithEvents Txt_Numerador As TextBox
    Friend WithEvents Txt_Denominador As TextBox
    Friend WithEvents Btm_Resultado As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label

End Class
