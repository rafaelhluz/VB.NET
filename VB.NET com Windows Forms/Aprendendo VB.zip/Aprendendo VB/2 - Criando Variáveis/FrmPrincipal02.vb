﻿Public Class FrmPrincipal02
    Public Sub New()

        ' Esta chamada é requerida pelo designer.
        InitializeComponent()

        ' Adicione qualquer inicialização após a chamada InitializeComponent().

    End Sub

    Private Sub Btm_Principal_Click(sender As Object, e As EventArgs) Handles Btm_NumerosInteiros.Click

        Dim idade As Integer
        idade = 12
        MsgBox("O valor da idade é " + idade.ToString, MsgBoxStyle.Critical)

        idade = 12 * 5
        MsgBox("O valor da idade multiplicado por 5 é " + idade.ToString, MsgBoxStyle.Critical)

        idade = (12 * 5) + 10
        MsgBox("O valor da idade multiplicado por 5 e somado de 10 é " + idade.ToString, MsgBoxStyle.Critical)

    End Sub

    Private Sub Btm_PontoFlutuante_Click(sender As Object, e As EventArgs) Handles Btm_PontoFlutuante.Click

        Dim Valor As Double
        Valor = 9.5
        MsgBox("Valor = " + Valor.ToString)

        Valor = 5 / 2
        MsgBox("Valor de 5/2 = " + Valor.ToString)

        Dim numerador = 5
        Dim denominador = 2

        Valor = numerador / denominador
        MsgBox("Valor de 5/2 = " + Valor.ToString)

    End Sub

    Private Sub BTm_ConversaoNumeros_Click(sender As Object, e As EventArgs) Handles BTm_ConversaoNumeros.Click

        Dim salario As Double = 1300.45

        Dim salarioInteiro As Integer = salario

        MsgBox("O valor do salário é " + salario.ToString + " e o valor do salario inteiro é " + salarioInteiro.ToString)

        Dim salarioGrande As Long = 1000000000000000000
        MsgBox("Limite do tipo Long é " + salarioGrande.ToString)

        Dim salarioMedio As Integer = 1000000000
        MsgBox("Limite do tipo Integer é " + salarioMedio.ToString)

        Dim salarioPequeno As Short = 10000
        MsgBox("Limite do tipo Short é " + salarioPequeno.ToString)

        Dim salarioMinusculo As SByte = 100
        MsgBox("Limite do tipo Sbyte é " + salarioMinusculo.ToString)

    End Sub
    Private Sub Btm_Resultado_Click(sender As Object, e As EventArgs) Handles Btm_Resultado.Click

        Dim numerador As Double = Txt_Numerador.Text
        Dim denominador As Double = Txt_Denominador.Text

        Dim resultado As Double = numerador / denominador
        MsgBox("O resultado entre a divisão de " + numerador.ToString + " por " _
               + denominador.ToString + " é " + resultado.ToString)


    End Sub

    Private Sub Txt_Numerador_TextChanged(sender As Object, e As EventArgs) Handles Txt_Numerador.TextChanged

    End Sub
End Class
