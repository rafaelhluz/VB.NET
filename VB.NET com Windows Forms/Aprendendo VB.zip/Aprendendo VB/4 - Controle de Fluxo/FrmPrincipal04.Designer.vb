﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Frm_Principal_04
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Button1 = New Button()
        Lbl_NomeProjeto = New Label()
        Lbl_Idade = New Label()
        Txt_Idade = New TextBox()
        Txt_Resultado = New TextBox()
        Lbl_Resultado = New Label()
        GrpPais = New GroupBox()
        RdbNao = New RadioButton()
        RdbSim = New RadioButton()
        GrpPais.SuspendLayout()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(12, 167)
        Button1.Name = "Button1"
        Button1.Size = New Size(276, 23)
        Button1.TabIndex = 0
        Button1.Text = "Clique aqui"
        Button1.UseVisualStyleBackColor = True
        Button1.UseWaitCursor = True
        ' 
        ' Lbl_NomeProjeto
        ' 
        Lbl_NomeProjeto.AutoSize = True
        Lbl_NomeProjeto.Location = New Point(12, 9)
        Lbl_NomeProjeto.Name = "Lbl_NomeProjeto"
        Lbl_NomeProjeto.Size = New Size(110, 15)
        Lbl_NomeProjeto.TabIndex = 1
        Lbl_NomeProjeto.Text = "1 - Primeiro Projeto"
        Lbl_NomeProjeto.UseWaitCursor = True
        ' 
        ' Lbl_Idade
        ' 
        Lbl_Idade.AutoSize = True
        Lbl_Idade.Location = New Point(12, 34)
        Lbl_Idade.Name = "Lbl_Idade"
        Lbl_Idade.Size = New Size(41, 15)
        Lbl_Idade.TabIndex = 2
        Lbl_Idade.Text = "Label1"
        Lbl_Idade.UseWaitCursor = True
        ' 
        ' Txt_Idade
        ' 
        Txt_Idade.Location = New Point(12, 52)
        Txt_Idade.Name = "Txt_Idade"
        Txt_Idade.Size = New Size(276, 23)
        Txt_Idade.TabIndex = 3
        Txt_Idade.UseWaitCursor = True
        ' 
        ' Txt_Resultado
        ' 
        Txt_Resultado.Location = New Point(12, 217)
        Txt_Resultado.Name = "Txt_Resultado"
        Txt_Resultado.Size = New Size(276, 23)
        Txt_Resultado.TabIndex = 4
        Txt_Resultado.UseWaitCursor = True
        ' 
        ' Lbl_Resultado
        ' 
        Lbl_Resultado.AutoSize = True
        Lbl_Resultado.Location = New Point(12, 199)
        Lbl_Resultado.Name = "Lbl_Resultado"
        Lbl_Resultado.Size = New Size(41, 15)
        Lbl_Resultado.TabIndex = 5
        Lbl_Resultado.Text = "Label1"
        Lbl_Resultado.UseWaitCursor = True
        ' 
        ' GrpPais
        ' 
        GrpPais.Controls.Add(RdbNao)
        GrpPais.Controls.Add(RdbSim)
        GrpPais.Location = New Point(12, 81)
        GrpPais.Name = "GrpPais"
        GrpPais.Size = New Size(276, 80)
        GrpPais.TabIndex = 6
        GrpPais.TabStop = False
        GrpPais.Text = "GroupBox1"
        GrpPais.UseWaitCursor = True
        ' 
        ' RdbNao
        ' 
        RdbNao.AutoSize = True
        RdbNao.Location = New Point(6, 55)
        RdbNao.Name = "RdbNao"
        RdbNao.Size = New Size(97, 19)
        RdbNao.TabIndex = 7
        RdbNao.TabStop = True
        RdbNao.Text = "RadioButton1"
        RdbNao.UseVisualStyleBackColor = True
        RdbNao.UseWaitCursor = True
        ' 
        ' RdbSim
        ' 
        RdbSim.AutoSize = True
        RdbSim.Location = New Point(6, 30)
        RdbSim.Name = "RdbSim"
        RdbSim.Size = New Size(97, 19)
        RdbSim.TabIndex = 7
        RdbSim.TabStop = True
        RdbSim.Text = "RadioButton1"
        RdbSim.UseVisualStyleBackColor = True
        RdbSim.UseWaitCursor = True
        ' 
        ' Frm_Principal_04
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(300, 339)
        Controls.Add(GrpPais)
        Controls.Add(Lbl_Resultado)
        Controls.Add(Txt_Resultado)
        Controls.Add(Txt_Idade)
        Controls.Add(Lbl_Idade)
        Controls.Add(Lbl_NomeProjeto)
        Controls.Add(Button1)
        Cursor = Cursors.IBeam
        Name = "Frm_Principal_04"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Aplicação Alô Mundo"
        UseWaitCursor = True
        GrpPais.ResumeLayout(False)
        GrpPais.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Lbl_NomeProjeto As Label
    Friend WithEvents Lbl_Idade As Label
    Friend WithEvents Txt_Idade As TextBox
    Friend WithEvents Txt_Resultado As TextBox
    Friend WithEvents Lbl_Resultado As Label
    Friend WithEvents GrpPais As GroupBox
    Friend WithEvents RdbSim As RadioButton
    Friend WithEvents RdbNao As RadioButton

End Class
