﻿Public Class Frm_Principal_04
    Public Sub New()

        ' Esta chamada é requerida pelo designer.
        InitializeComponent()

        ' Adicione qualquer inicialização após a chamada InitializeComponent().


        Lbl_NomeProjeto.Text = "4 - Controle de Fluxo"
        Button1.Text = "Checagem da permissão de entrada"
        Me.Text = "4 - Controle de Fluxo"

        ' Inicialização dos componentes da aplicação

        Lbl_Idade.Text = "Idade"
        Lbl_Resultado.Text = "Resultado"
        GrpPais.Text = "Acompanhado dos pais?"
        RdbSim.Text = "Sim"
        RdbNao.Text = "Não"

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Txt_Resultado.Text = ""
        Dim idade As Integer = Txt_Idade.Text
        Dim acompanhado As String

        If RdbSim.Checked Then
            acompanhado = "S"

        Else
            acompanhado = "N"

        End If

        Dim liberado As Boolean = (idade >= 18) Or (acompanhado = "S" And idade >= 16)
        Dim negado As Boolean = (acompanhado = "N" And idade >= 16) Or (idade < 16)

        If liberado Then
            Txt_Resultado.ForeColor = Color.Green
            Txt_Resultado.Text = "Liberado"

        Else
            If negado Then
                Txt_Resultado.ForeColor = Color.Red
                Txt_Resultado.Text = "Negado"

            End If

        End If

    End Sub

End Class
